<?php
$con = mysqli_connect('localhost','root','','crud');
if($con){
	
}else{
	echo "Not Connected";
}

?>